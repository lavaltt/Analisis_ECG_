# -*- coding: utf-8 -*-
"""
Created on Sat Oct 26 08:22:45 2024

@author: Automatizacion 2
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy import signal
from scipy.signal import find_peaks
import  pywt

# Lee los datos como texto
with open(r'C:\Users\Automatizacion 2\Downloads\V\Señales\Lab4\datosECG4.csv', 'r', encoding='utf-8') as file:
    # Lee todas las líneas y elimina espacios en blanco
    lines = file.readlines()

# Convierte las líneas a una lista de números, reemplazando comas por puntos
data = []
for line in lines:
    line = line.strip().replace(',', '.')  # Elimina espacios y reemplaza comas
    try:
        value = float(line)  # Convierte a float
        data.append(value)
    except ValueError:
        continue  # Ignora líneas que no se pueden convertir

# Convierte a un array de numpy
data = np.array(data)

# Configura la frecuencia de muestreo (ajústala a la frecuencia real)
fs = 250  # Hz, por ejemplo

# Imprime las primeras filas para verificar los datos
print(data[:5])

# Genera el eje de tiempo
tiempo = np.arange(len(data)) / fs

# Grafica la señal
plt.figure(figsize=(50, 10))
plt.plot(tiempo, data, color='red')
plt.title("Señal ECG")
plt.xlabel("Tiempo (s)")
plt.ylabel("Amplitud (V)")
plt.grid()
plt.show()

#%%ESTADISTICAS DE LA SENAL CRUDA
# Calcular estadísticas de los intervalos R-R
media = np.mean(data)
mediana = np.median(data)
desviacion= np.std(data)

# Imprimir estadísticas generales
print(f"Media de la senal original: {media:.4f}")
print(f"Mediana de la senal original : {mediana:.4f}")
print(f"Desviación estándar de la senal original: {desviacion:.4f}")


#%%FILTROS 
# Parámetros del filtro pasa banda
lc = 5.0    # Frecuencia de corte baja para el pasa banda
hc = 100.0   # Frecuencia de corte alta para el pasa banda
order_bandpass = 3  # Orden del filtro pasa banda

# Normalización para el filtro pasa banda
nyquist = 0.5 * fs
low = lc / nyquist
high = hc / nyquist

# Filtro pasa banda Butterworth
b_bandpass, a_bandpass = signal.butter(order_bandpass, [low, high], btype='band')
filtered_data = signal.filtfilt(b_bandpass, a_bandpass, data)

# Parámetros para el filtro de rechaza banda (50-60 Hz)
stop_low = 50.0
stop_high = 60.0
order_bandstop = 5  # Orden del filtro rechaza banda
low_stop = stop_low / nyquist
high_stop = stop_high / nyquist

# Filtro rechaza banda Butterworth
b_bandstop, a_bandstop = signal.butter(order_bandstop, [low_stop, high_stop], btype='bandstop')
filtered_bandstop_data = signal.filtfilt(b_bandstop, a_bandstop, filtered_data)

# Genera el eje de tiempo
tiempo = np.arange(len(data)) / fs

# Gráficas
plt.figure(figsize=(50, 8))

plt.subplot(3, 1, 1)
plt.plot(tiempo, data, color='red')
plt.title("Señal ECG Original")
plt.xlabel("Tiempo (s)")
plt.ylabel("Amplitud (V)")
plt.grid()

plt.subplot(3, 1, 2)
plt.plot(tiempo, filtered_data, color='green')
plt.title(f"Señal ECG Filtrada (Pasa de Banda {lc}-{hc} Hz, Orden {order_bandpass})")
plt.xlabel("Tiempo (s)")
plt.ylabel("Amplitud (V)")
plt.grid()

plt.subplot(3, 1, 3)
plt.plot(tiempo, filtered_bandstop_data, color='blue')
plt.title(f"Señal ECG Filtrada (Pasa de Banda + Rechaza Banda {stop_low}-{stop_high} Hz, Orden {order_bandstop})")
plt.xlabel("Tiempo (s)")
plt.ylabel("Amplitud (V)")
plt.grid()

plt.tight_layout()
plt.show()

#%%DETECCION DE INTERVALOS R-R
# Detección de picos R en la señal filtrada
distance = int(0.6 * fs)  # Define una distancia mínima entre picos en muestras (600 ms aprox.)
peaks, _ = find_peaks(filtered_bandstop_data, distance=distance, height=0.5)  # Ajusta el umbral según la señal

# Calcular los intervalos R-R
intervalos_RR = np.diff(peaks) / fs  # Convertimos a segundos
num_picos = len(peaks)
num_intervalos = len(intervalos_RR)

# Imprimir información
print(f"Número de picos R detectados: {num_picos}")
print(f"Número de intervalos R-R: {num_intervalos}")
print(f"Duración de cada intervalo R-R en segundos: {intervalos_RR}")

# Gráfica de la señal con los picos R marcados
plt.figure(figsize=(50, 10))
plt.plot(tiempo, filtered_bandstop_data, label='Señal ECG Filtrada', color='blue')
plt.plot(tiempo[peaks], filtered_bandstop_data[peaks], "x", label="Picos R", color='red')  # Marcamos los picos R
plt.title("Señal ECG Filtrada con Picos R Identificados")
plt.xlabel("Tiempo (s)")
plt.ylabel("Amplitud (V)")
plt.legend()
plt.grid()


#%%ESTADISTICAS 
# Calcular estadísticas de los intervalos R-R
media_RR = np.mean(intervalos_RR)
mediana_RR = np.median(intervalos_RR)
desviacion_std_RR = np.std(intervalos_RR)

# Imprimir estadísticas generales
print(f"Media de los intervalos R-R: {media_RR:.4f} segundos")
print(f"Mediana de los intervalos R-R: {mediana_RR:.4f} segundos")
print(f"Desviación estándar de los intervalos R-R: {desviacion_std_RR:.4f} segundos")



# Gráfica de los intervalos R-R con promedios
plt.figure(figsize=(20, 5))

# Suavizar usando un promedio móvil
window_size = 5  # Tamaño de la ventana para el promedio móvil
smoothed_intervals = np.convolve(intervalos_RR, np.ones(window_size) / window_size, mode='valid')

plt.plot(smoothed_intervals, marker='o', linestyle='-', color='purple', label='Intervalos R-R Suavizados')
plt.axhline(y=media_RR, color='red', linestyle='--', label='Media de Intervalos R-R')
plt.axhline(y=media_RR + desviacion_std_RR, color='green', linestyle='--', label='Media + 1 Desviación Estándar')
plt.axhline(y=media_RR - desviacion_std_RR, color='orange', linestyle='--', label='Media - 1 Desviación Estándar')
plt.title("Duración de los Intervalos R-R (Suavizados)")
plt.xlabel("Índice del Intervalo")
plt.ylabel("Duración (s)")
plt.legend()
plt.grid()
plt.show()


#%%TRANSFORMADA WAVELET

# Sección para el análisis HRV en el dominio de la frecuencia usando la transformada wavelet continua

# Elegir la wavelet adecuada (por ejemplo, 'cmor' para Morlet)
wavelet = 'cmor'  # Wavelet de Morlet

# Definir la gama de escalas (frecuencias)
# Puedes ajustar las escalas según sea necesario
scales = np.arange(0.5, 100)  # Ajusta según el tamaño de tus datos

# Calcular la transformada wavelet continua (CWT) en la señal filtrada
coefficients, frequencies = pywt.cwt(filtered_bandstop_data, wavelet, scales, sampling_period=1/fs)

# Calcular el espectrograma (energía) de los coeficientes
power = np.abs(coefficients) ** 2

# Gráfica del espectrograma
plt.figure(figsize=(20, 10))
plt.imshow(power, extent=[0, len(filtered_bandstop_data) / fs, frequencies[-1], frequencies[0]], aspect='auto',
           cmap='jet', interpolation='bilinear')
plt.colorbar(label='Potencia (Escala de color)')
plt.title('Espectrograma de la Señal ECG Filtrada utilizando la Transformada Wavelet Continua')
plt.xlabel('Tiempo (s)')
plt.ylabel('Frecuencia (Hz)')
plt.ylim([0.1, 2])  # Ajusta el rango de frecuencias según sea necesario
plt.grid()
plt.show()